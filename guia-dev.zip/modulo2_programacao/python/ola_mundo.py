nome = input("Digite seu nome: ")
for i in range(3):
    print(f"Olá, {nome}! Bem-vindo(a) ao mundo da programação.")
