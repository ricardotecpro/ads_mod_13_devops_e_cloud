# Módulo 0 — Ambientação

Organize seu ambiente de trabalho antes de começar.

## Estrutura de pastas sugerida
```
/projetos
/documentos
/downloads
```

## Backup de código
- GitHub (público ou privado)
- Google Drive ou Dropbox

## Ferramentas que serão usadas
- VS Code ou IntelliJ
- Git
- Terminal (Windows ou Linux)
- Docker
