# Exemplo de uso do Git

```bash
git init
echo "# Meu Repositório" > README.md
git add README.md
git commit -m "Primeiro commit"
git branch -M main
git remote add origin https://github.com/usuario/repositorio.git
git push -u origin main
```
